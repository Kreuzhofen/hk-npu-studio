from __future__ import annotations

from dataclasses import dataclass, asdict
from typing import Any


@dataclass(frozen=True)
class PipelineParameters:
    """Immutable parameter contract shared by CPU, ONNX, and QNN pipelines."""
    prompt: str
    negative_prompt: str
    model_name: str
    width: int
    height: int
    steps: int
    cfg_scale: float
    seed: int
    sampler: str
    scheduler: str
    batch_size: int
    output_directory: str
    output_prefix: str
    input_image_path: str | None
    controlnet_enabled: bool
    canny_low_threshold: int
    canny_high_threshold: int
    controlnet_conditioning_scale: float

    @classmethod
    def from_session(cls, session: "GenerationSessionModel") -> "PipelineParameters":
        return cls(**session.to_dict())

    def to_worker_dict(self, job_id: Any) -> dict[str, Any]:
        values = asdict(self)
        values["job_id"] = str(job_id)
        return values


@dataclass
class GenerationSessionModel:
    """
    Central model serving as the Single Source of Truth for all AI image and video generations.
    Holds model configuration, prompts, resolution and sampling parameters.
    """
    prompt: str = ""
    negative_prompt: str = ""
    model_name: str = "sd_xl_base_1.0"
    width: int = 512
    height: int = 512
    steps: int = 20
    cfg_scale: float = 7.0
    seed: int = -1
    sampler: str = "Euler a"
    scheduler: str = "Normal"
    batch_size: int = 1
    output_directory: str = "output"
    output_prefix: str = "generate"
    input_image_path: str | None = None
    controlnet_enabled: bool = False
    canny_low_threshold: int = 50
    canny_high_threshold: int = 150
    controlnet_conditioning_scale: float = 1.0

    def reset(self) -> None:
        """Reset all parameters to default values."""
        self.prompt = ""
        self.negative_prompt = ""
        self.model_name = "sd_xl_base_1.0"
        self.width = 512
        self.height = 512
        self.steps = 20
        self.cfg_scale = 7.0
        self.seed = -1
        self.sampler = "Euler a"
        self.scheduler = "Normal"
        self.batch_size = 1
        self.output_directory = "output"
        self.output_prefix = "generate"
        self.input_image_path = None
        self.controlnet_enabled = False
        self.canny_low_threshold = 50
        self.canny_high_threshold = 150
        self.controlnet_conditioning_scale = 1.0

    def update(self, **kwargs: Any) -> None:
        """Update fields dynamically."""
        for key, value in kwargs.items():
            if hasattr(self, key):
                setattr(self, key, value)

    def to_dict(self) -> dict[str, Any]:
        """Serialize session model parameters to a dict."""
        return asdict(self)
